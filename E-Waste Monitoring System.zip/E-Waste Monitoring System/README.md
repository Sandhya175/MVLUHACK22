
  # E-Waste Monitoring System

  This is a code bundle for E-Waste Monitoring System. The original project is available at https://www.figma.com/design/VoVJnfLVBV0T8f4ynFOvSD/E-Waste-Monitoring-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  